#ifndef _PPM_STATE_H_
#define _PPM_STATE_H_

enum PPMState {
    PPM_CODE,
    PPM_SIZE,
    PPM_LEVEL,
    PPM_PIXEL
};

enum PPMColorState {
    RED,
    GREEN,
    BLUE
};

#endif
