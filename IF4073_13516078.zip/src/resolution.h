#ifndef _RESOLUTION_H_
#define _RESOLUTION_H_

struct Resolution {
    unsigned int width;
    unsigned int height;
};

#endif