#ifndef _TRANSFORMATION_H_
#define _TRANSFORMATION_H_

using namespace std;

enum Transformation {
    LOG,
    INVERSE_LOG,
    POWER
};

#endif
