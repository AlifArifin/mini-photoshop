#ifndef _PGM_STATE_H_
#define _PGM_STATE_H_

enum PGMState {
    PGM_CODE,
    PGM_SIZE,
    PGM_LEVEL,
    PGM_PIXEL
};

#endif
