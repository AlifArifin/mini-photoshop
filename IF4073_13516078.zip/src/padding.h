#ifndef _PADDING_H_
#define _PADDING_H_

enum Padding {
    ZERO,
    SAME
};

#endif