#ifndef _MAPPING_H_
#define _MAPPING_H_

struct Mapping {
    short* value;
    float* real;
    int size;
};

#endif