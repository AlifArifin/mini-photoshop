#ifndef _CONVOLUTION_H_
#define _CONVOLUTION_H_

using namespace std;

enum Convolution {
    BASIC,
    MEDIAN,
    NO_CLIPPING
};

#endif