#ifndef _OPERATION_H_
#define _OPERATION_H_

using namespace std;

enum Operation {
    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVISION,
    AND,
    OR,
    NOT,
    ADD_ABS
};

#endif