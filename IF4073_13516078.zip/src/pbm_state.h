#ifndef _PBM_STATE_H_
#define _PBM_STATE_H_

enum PBMState {
    PBM_CODE,
    PBM_SIZE,
    PBM_PIXEL
};

#endif
