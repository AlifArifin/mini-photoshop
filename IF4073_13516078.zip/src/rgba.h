#ifndef _RGBA_H_
#define _RGBA_H_

struct RGBA {
    short r;
    short g;
    short b;
    short a;
};

struct RGBAFloat {
    float r;
    float g;
    float b;
    float a;
};

#endif